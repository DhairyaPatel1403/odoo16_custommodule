{
    'name': 'Mail Custom Module',
    'version': '1.0',
    'category': 'Tools',
    'summary': 'Custom module to add buttons to ChatterTopbar',
    'depends': ['mail', 'web', 'base'],
    'data': [
        # 'views/chatter_topbar.xml',  # XML to define the buttons in ChatterTopbar
    ],
    'assets': {
        'web.assets_backend': [
            'mail_custom/static/src/js/chatter_button.js',
            'mail_custom/static/src/xml/chatter_topbar.xml',  # (Optional) JavaScript if needed for button functionality
            
        ],
    },
    'installable': True,
    'auto_install': False,
    'application':True
}
